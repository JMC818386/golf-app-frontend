#!/usr/bin/env python3
import os
import sys
import django

# Add the project directory to Python path
sys.path.insert(0, '/workspace/golf-app-backend')
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'api.settings')

django.setup()

from scoretracker.models import CustomUser
from django.contrib.auth.hashers import make_password

print("🔍 Checking existing users...")
existing_users = CustomUser.objects.all()
print(f"Found {existing_users.count()} existing users:")
for user in existing_users:
    print(f"  - {user.username} ({'admin' if user.is_superuser else 'regular user'})")

print("\n🔧 Creating new users...")

# Create admin superuser
if not CustomUser.objects.filter(username='admin').exists():
    admin_user = CustomUser.objects.create(
        username='admin',
        email='admin@example.com',
        password=make_password('admin123'),
        is_superuser=True,
        is_staff=True,
        is_active=True
    )
    print("✅ Admin superuser created successfully!")
else:
    print("ℹ️  Admin user already exists")

# Create regular test user  
if not CustomUser.objects.filter(username='testuser').exists():
    test_user = CustomUser.objects.create(
        username='testuser',
        email='test@example.com', 
        password=make_password('testpass123'),
        first_name='Test',
        last_name='User',
        is_active=True
    )
    print("✅ Test user created successfully!")
else:
    print("ℹ️  Test user already exists")

print("\n" + "="*50)
print("🎉 YOUR LOGIN CREDENTIALS")
print("="*50)
print("🔧 Django Admin Panel:")
print("   URL: http://localhost:8000/admin/")
print("   Username: admin")
print("   Password: admin123")
print()
print("🎯 Frontend Application:")
print("   URL: http://localhost:3000")
print("   Username: testuser") 
print("   Password: testpass123")
print("="*50)
