#!/bin/bash
export DATABASE_URL="postgres://admin:PAss33word@//cloudsql/pocket-pro-api:us-central1:pocket-pro-db/pocketpro_db"
export USE_CLOUD_SQL_AUTH_PROXY=true
export SECRET_KEY="vxndTUJDosRnNZthgPAiyFOJcxBhwMCDtUyOSiQUVYkOfVkbjI"
python manage.py migrate
