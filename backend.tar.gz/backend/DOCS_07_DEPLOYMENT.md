# PocketPro Golf App - Deployment & DevOps Guide

## Deployment Platforms

### Google Cloud Platform (App Engine)

**Current Production URL**: `https://pocket-pro-api.ue.r.appspot.com`

---

## App Engine Configuration

### app.yaml
Location: Project root

```yaml
# Runtime configuration
runtime: python310

# Environment variables
env_variables:
  APPENGINE_URL: pocket-pro-api.ue.r.appspot.com

# Static file handlers
handlers:
- url: /static
  static_dir: static/

# Main application handler
- url: /.*
  script: auto
```

### Key Features
- **Runtime**: Python 3.10
- **Auto-scaling**: Enabled by default
- **Static Files**: Served directly by App Engine
- **HTTPS**: Automatic SSL certificate

---

## Database Configuration

### Cloud SQL (PostgreSQL)

#### Connection Methods

**1. Direct Connection**
```python
DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.postgresql",
        "HOST": "/cloudsql/PROJECT:REGION:INSTANCE",
        "USER": "postgres",
        "PASSWORD": "your-password",
        "NAME": "golf_db"
    }
}
```

**2. Cloud SQL Auth Proxy**
```python
if os.getenv("USE_CLOUD_SQL_AUTH_PROXY", None):
    DATABASES["default"]["HOST"] = "127.0.0.1"
    DATABASES["default"]["PORT"] = 5432
```

Local proxy command:
```bash
cloud_sql_proxy -instances=PROJECT:REGION:INSTANCE=tcp:5432
```

---

## Secret Management

### Google Cloud Secret Manager

#### Creating Secrets

**1. Create Secret File** (`.env` format):
```env
SECRET_KEY=your-django-secret-key-here
DATABASE_URL=postgresql://user:pass@/cloudsql/PROJECT:REGION:INSTANCE/dbname
```

**2. Upload to Secret Manager**:
```bash
# Create secret
gcloud secrets create django_settings \
    --data-file=.env \
    --replication-policy="automatic"

# Grant access to App Engine
gcloud secrets add-iam-policy-binding django_settings \
    --member="serviceAccount:PROJECT@appspot.gserviceaccount.com" \
    --role="roles/secretmanager.secretAccessor"
```

**3. Update Secret**:
```bash
gcloud secrets versions add django_settings --data-file=.env
```

#### Environment Detection
```python
# Priority:
# 1. Local .env file (development)
# 2. Google Cloud Secret Manager (production)

if os.path.isfile(env_file):
    env.read_env(env_file)
elif os.environ.get("GOOGLE_CLOUD_PROJECT", None):
    project_id = os.environ.get("GOOGLE_CLOUD_PROJECT")
    client = secretmanager.SecretManagerServiceClient()
    settings_name = os.environ.get("SETTINGS_NAME", "django_settings")
    name = f"projects/{project_id}/secrets/{settings_name}/versions/latest"
    payload = client.access_secret_version(name=name).payload.data.decode("UTF-8")
    env.read_env(io.StringIO(payload))
else:
    raise Exception("No local .env or GOOGLE_CLOUD_PROJECT detected.")
```

---

## Deployment Process

### Initial Setup

**1. Install Google Cloud SDK**:
```bash
# macOS
brew install google-cloud-sdk

# Initialize
gcloud init
gcloud auth login
```

**2. Set Project**:
```bash
gcloud config set project YOUR_PROJECT_ID
```

**3. Enable Required APIs**:
```bash
gcloud services enable appengine.googleapis.com
gcloud services enable sqladmin.googleapis.com
gcloud services enable secretmanager.googleapis.com
```

**4. Create App Engine App**:
```bash
gcloud app create --region=us-east1
```

---

### Database Setup

**1. Create Cloud SQL Instance**:
```bash
gcloud sql instances create golf-db-instance \
    --database-version=POSTGRES_15 \
    --tier=db-f1-micro \
    --region=us-east1
```

**2. Set Root Password**:
```bash
gcloud sql users set-password postgres \
    --instance=golf-db-instance \
    --password=YOUR_SECURE_PASSWORD
```

**3. Create Database**:
```bash
gcloud sql databases create golf_db \
    --instance=golf-db-instance
```

**4. Get Connection Name**:
```bash
gcloud sql instances describe golf-db-instance \
    --format="value(connectionName)"
# Output: PROJECT:REGION:INSTANCE
```

---

### Pre-Deployment Checklist

- [ ] Update `SECRET_KEY` in Secret Manager
- [ ] Set `DEBUG = False` in production
- [ ] Configure `ALLOWED_HOSTS`
- [ ] Set `DATABASE_URL` with Cloud SQL path
- [ ] Run database migrations
- [ ] Collect static files
- [ ] Test authentication flow
- [ ] Verify CORS settings
- [ ] Check environment variables

---

### Deploy to App Engine

**1. Collect Static Files**:
```bash
python manage.py collectstatic --noinput
```

**2. Run Migrations** (via proxy):
```bash
# Start Cloud SQL Proxy
cloud_sql_proxy -instances=PROJECT:REGION:INSTANCE=tcp:5432 &

# Run migrations
python manage.py migrate

# Load fixtures
python manage.py loaddata scoretracker/fixtures/course.json
python manage.py loaddata scoretracker/fixtures/holes.json
```

**3. Deploy Application**:
```bash
gcloud app deploy

# With version specified
gcloud app deploy --version=v1

# Promote to receive traffic
gcloud app deploy --promote

# No promote (for testing)
gcloud app deploy --no-promote
```

**4. View Logs**:
```bash
gcloud app logs tail -s default
```

**5. Open Application**:
```bash
gcloud app browse
```

---

## Local Development

### Docker Compose Setup

**docker-compose.yml**:
```yaml
services:
  postgres:
    image: postgres:15.0
    ports:
      - 5432:5432
    environment:
      - "POSTGRES_PASSWORD=postgres"
```

**Commands**:
```bash
# Start PostgreSQL
docker-compose up -d

# Stop PostgreSQL
docker-compose down

# View logs
docker-compose logs -f

# Remove volumes (clean slate)
docker-compose down -v
```

---

### Local Development Workflow

**1. Environment Setup**:
```bash
# Create virtual environment
python -m venv venv
source venv/bin/activate  # or venv\Scripts\activate on Windows

# Install dependencies
pip install -r requirements.txt
```

**2. Database Setup**:
```bash
# Start PostgreSQL
docker-compose up -d

# Create .env file
cat > .env << EOF
SECRET_KEY=django-insecure-local-development-key-12345
DATABASE_URL=postgresql://postgres:postgres@localhost:5432/golf_db
DEBUG=True
EOF

# Run migrations
python manage.py migrate

# Load fixtures
python manage.py loaddata scoretracker/fixtures/course.json
python manage.py loaddata scoretracker/fixtures/holes.json

# Create superuser
python manage.py createsuperuser
```

**3. Run Server**:
```bash
python manage.py runserver
```

**4. Access Application**:
- **API**: http://localhost:8000/api/
- **Admin**: http://localhost:8000/admin/

---

## CI/CD Pipeline Suggestions

### GitHub Actions Workflow

**.github/workflows/deploy.yml**:
```yaml
name: Deploy to App Engine

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest
    
    steps:
    - uses: actions/checkout@v3
    
    - name: Set up Python
      uses: actions/setup-python@v4
      with:
        python-version: '3.10'
    
    - name: Install dependencies
      run: |
        pip install -r requirements.txt
    
    - name: Run tests
      run: |
        python manage.py test
    
    - name: Authenticate to Google Cloud
      uses: google-github-actions/auth@v1
      with:
        credentials_json: ${{ secrets.GCP_SA_KEY }}
    
    - name: Set up Cloud SDK
      uses: google-github-actions/setup-gcloud@v1
    
    - name: Deploy to App Engine
      run: |
        gcloud app deploy --quiet
```

---

## Monitoring & Logging

### Cloud Logging

**View Logs**:
```bash
# Tail logs
gcloud app logs tail -s default

# Filter by severity
gcloud app logs tail -s default --level=error

# View in browser
gcloud app logs read --limit=50
```

### Cloud Monitoring

**Metrics to Monitor**:
- Request count
- Response time
- Error rate
- Database connections
- Memory usage
- CPU usage

**Setup Alerts**:
```bash
# Create alert policy via Console
# Monitor: Error rate > 5%
# Notification: Email/SMS
```

---

## Scaling Configuration

### App Engine Scaling

**Automatic Scaling** (default):
```yaml
automatic_scaling:
  target_cpu_utilization: 0.65
  min_instances: 1
  max_instances: 10
  min_idle_instances: 0
  max_idle_instances: 1
```

**Basic Scaling** (alternative):
```yaml
basic_scaling:
  max_instances: 5
  idle_timeout: 10m
```

**Manual Scaling** (alternative):
```yaml
manual_scaling:
  instances: 2
```

---

## Database Maintenance

### Backup Strategy

**1. Automated Backups**:
```bash
# Enable automated backups
gcloud sql instances patch golf-db-instance \
    --backup-start-time=02:00
```

**2. On-Demand Backup**:
```bash
gcloud sql backups create \
    --instance=golf-db-instance
```

**3. Export Database**:
```bash
# Export to Cloud Storage
gcloud sql export sql golf-db-instance \
    gs://your-bucket/backup-$(date +%Y%m%d).sql \
    --database=golf_db
```

### Migrations

**Apply Migrations in Production**:
```bash
# Via Cloud SQL Proxy
cloud_sql_proxy -instances=PROJECT:REGION:INSTANCE=tcp:5432 &
python manage.py migrate

# Or via Cloud Shell
gcloud sql connect golf-db-instance --user=postgres
# Then run migrations through Django
```

---

## Security Best Practices

### Application Security
- ✅ Use Secret Manager for sensitive data
- ✅ Enable HTTPS/SSL (automatic on App Engine)
- ✅ Set `DEBUG = False` in production
- ✅ Restrict `ALLOWED_HOSTS`
- ✅ Use strong `SECRET_KEY`
- ✅ Enable CSRF protection
- ✅ Implement rate limiting
- ✅ Use parameterized queries (Django ORM)

### Database Security
- ✅ Use Cloud SQL with private IP
- ✅ Strong passwords for database users
- ✅ Enable automated backups
- ✅ Restrict database access to App Engine
- ✅ Use SSL connections
- ✅ Regular security updates

### IAM & Access Control
```bash
# Grant minimum necessary permissions
# App Engine service account needs:
# - Secret Manager Secret Accessor
# - Cloud SQL Client
```

---

## Cost Optimization

### App Engine
- Use automatic scaling with appropriate limits
- Set `min_instances: 0` for dev environments
- Use `F1` instance class for low-traffic apps

### Cloud SQL
- Use `db-f1-micro` for development
- Enable automatic storage increase
- Set maintenance windows during low traffic
- Consider read replicas for high-traffic

### Storage
- Clean up old backups
- Use lifecycle policies on Cloud Storage
- Compress static files

---

## Troubleshooting

### Common Issues

**1. Database Connection Failed**
```bash
# Check Cloud SQL status
gcloud sql instances describe golf-db-instance

# Verify connection string
echo $DATABASE_URL

# Test proxy connection
cloud_sql_proxy -instances=PROJECT:REGION:INSTANCE=tcp:5432
```

**2. Secret Not Found**
```bash
# List secrets
gcloud secrets list

# Check permissions
gcloud secrets get-iam-policy django_settings
```

**3. Static Files Not Serving**
```bash
# Collect static files
python manage.py collectstatic --noinput

# Verify handler in app.yaml
# Should have /static mapping
```

**4. CORS Errors**
- Check `CORS_ALLOWED_ORIGIN_REGEXES`
- Verify `CSRF_TRUSTED_ORIGINS`
- Ensure frontend origin is allowed

---

## Performance Optimization

### Database Optimization
- Add indexes on frequently queried fields
- Use `select_related()` for foreign keys
- Use `prefetch_related()` for reverse lookups
- Enable connection pooling

### Caching
- Implement Redis/Memcached
- Cache course and hole data
- Cache user sessions
- Use ETags for API responses

### CDN Integration
- Use Cloud CDN for static files
- Enable compression
- Set appropriate cache headers

---

## Rollback Procedure

**1. List Versions**:
```bash
gcloud app versions list
```

**2. Rollback to Previous**:
```bash
# Set traffic to previous version
gcloud app services set-traffic default \
    --splits=v1=1 \
    --quiet
```

**3. Delete Failed Version**:
```bash
gcloud app versions delete v2
```

---

## Environment-Specific Configurations

### Development
```python
DEBUG = True
ALLOWED_HOSTS = ['*']
CORS_ALLOW_ALL_ORIGINS = True
```

### Staging
```python
DEBUG = False
ALLOWED_HOSTS = ['staging-app.ue.r.appspot.com']
CORS_ALLOWED_ORIGIN_REGEXES = [r"^https://staging-.*\.web\.app$"]
```

### Production
```python
DEBUG = False
ALLOWED_HOSTS = ['pocket-pro-api.ue.r.appspot.com']
CORS_ALLOWED_ORIGIN_REGEXES = [r"^https://.*\.web\.app$"]
SECURE_SSL_REDIRECT = True
```
