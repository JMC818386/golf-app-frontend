# PocketPro Golf App - Integration Guide for Clover Golf Production

## Purpose
This document provides a comprehensive guide for integrating the PocketPro backend with the Clover Golf frontend to create **"Clover Golf - Production"**, a complete full-stack golf application.

---

## Integration Architecture

### System Overview
```
┌─────────────────────────────────────────────────────────────┐
│                  Clover Golf - Production                    │
├──────────────────────────┬──────────────────────────────────┤
│                          │                                   │
│    Frontend (Clover)     │    Backend (PocketPro)           │
│    ─────────────────     │    ──────────────────            │
│    • React/Vue/Angular   │    • Django REST API             │
│    • UI Components       │    • PostgreSQL Database         │
│    • State Management    │    • JWT Authentication          │
│    • Routing            │    • Business Logic              │
│                          │                                   │
└──────────────────────────┴──────────────────────────────────┘
```

---

## API Integration Strategy

### Base Configuration

**Environment Variables** (Frontend):
```javascript
// .env or .env.production
VITE_API_BASE_URL=https://pocket-pro-api.ue.r.appspot.com/api
// or for development
VITE_API_BASE_URL=http://localhost:8000/api
```

### API Client Setup

**Axios Configuration** (Recommended):
```javascript
// src/api/client.js
import axios from 'axios';

const apiClient = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL,
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor - Add JWT token
apiClient.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('accessToken');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Response interceptor - Handle token refresh
apiClient.interceptors.response.use(
  (response) => response,
  async (error) => {
    const originalRequest = error.config;
    
    // If 401 and not already retried
    if (error.response?.status === 401 && !originalRequest._retry) {
      originalRequest._retry = true;
      
      try {
        const refreshToken = localStorage.getItem('refreshToken');
        const response = await axios.post(
          `${import.meta.env.VITE_API_BASE_URL}/token/refresh/`,
          { refresh: refreshToken }
        );
        
        const { access, refresh } = response.data;
        localStorage.setItem('accessToken', access);
        localStorage.setItem('refreshToken', refresh);
        
        originalRequest.headers.Authorization = `Bearer ${access}`;
        return apiClient(originalRequest);
      } catch (refreshError) {
        // Refresh failed - redirect to login
        localStorage.removeItem('accessToken');
        localStorage.removeItem('refreshToken');
        window.location.href = '/login';
        return Promise.reject(refreshError);
      }
    }
    
    return Promise.reject(error);
  }
);

export default apiClient;
```

---

## Authentication Integration

### User Registration

**Frontend Component**:
```javascript
// src/services/authService.js
import apiClient from '../api/client';

export const registerUser = async (userData) => {
  try {
    const response = await apiClient.post('/user/signup/', {
      email: userData.email,
      username: userData.username,
      password: userData.password,
      first_name: userData.firstName,
      last_name: userData.lastName,
    });
    return { success: true, data: response.data };
  } catch (error) {
    return { 
      success: false, 
      errors: error.response?.data || { message: 'Registration failed' }
    };
  }
};
```

**Usage in Component**:
```javascript
// CreateAccountPage.jsx
import { registerUser } from '../services/authService';

const handleSubmit = async (formData) => {
  const result = await registerUser(formData);
  
  if (result.success) {
    // Auto-login after registration
    await loginUser({
      username: formData.username,
      password: formData.password
    });
    navigate('/dashboard');
  } else {
    setErrors(result.errors);
  }
};
```

---

### User Login

**Login Service**:
```javascript
export const loginUser = async (credentials) => {
  try {
    const response = await apiClient.post('/user/login/', {
      username: credentials.username,
      password: credentials.password,
    });
    
    const { access, refresh } = response.data;
    
    // Store tokens
    localStorage.setItem('accessToken', access);
    localStorage.setItem('refreshToken', refresh);
    
    // Decode token to get user info
    const userInfo = jwtDecode(access);
    localStorage.setItem('userId', userInfo.user_id);
    
    return { success: true, tokens: response.data };
  } catch (error) {
    return { 
      success: false, 
      error: error.response?.data?.detail || 'Login failed'
    };
  }
};
```

---

### Logout

**Logout Service**:
```javascript
export const logoutUser = () => {
  localStorage.removeItem('accessToken');
  localStorage.removeItem('refreshToken');
  localStorage.removeItem('userId');
  window.location.href = '/login';
};
```

---

## Data Integration Patterns

### Course Management

**Fetch Courses**:
```javascript
// src/services/courseService.js
import apiClient from '../api/client';

export const getCourses = async () => {
  try {
    const response = await apiClient.get('/courses/');
    return { success: true, courses: response.data };
  } catch (error) {
    return { success: false, error: error.message };
  }
};

export const getCourseById = async (courseId) => {
  try {
    const response = await apiClient.get(`/courses/${courseId}/`);
    return { success: true, course: response.data };
  } catch (error) {
    return { success: false, error: error.message };
  }
};
```

**React Hook Example**:
```javascript
// src/hooks/useCourses.js
import { useState, useEffect } from 'react';
import { getCourses } from '../services/courseService';

export const useCourses = () => {
  const [courses, setCourses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchCourses = async () => {
      setLoading(true);
      const result = await getCourses();
      
      if (result.success) {
        setCourses(result.courses);
      } else {
        setError(result.error);
      }
      setLoading(false);
    };

    fetchCourses();
  }, []);

  return { courses, loading, error };
};
```

---

### Hole Management

**Fetch Holes by Course**:
```javascript
// src/services/holeService.js
export const getHolesByCourse = async (courseId) => {
  try {
    const response = await apiClient.get('/holes/', {
      params: { selected_course: courseId }
    });
    return { success: true, holes: response.data };
  } catch (error) {
    return { success: false, error: error.message };
  }
};
```

---

### Round Management

**Create New Round**:
```javascript
// src/services/roundService.js
export const createRound = async (roundData) => {
  try {
    const response = await apiClient.post('/rounds/', {
      course: roundData.courseId,
      round_length: roundData.roundLength,
      total_score: 0, // Updated as round progresses
    });
    return { success: true, round: response.data };
  } catch (error) {
    return { success: false, error: error.message };
  }
};
```

**Get User Rounds**:
```javascript
export const getUserRounds = async () => {
  try {
    const response = await apiClient.get('/rounds/');
    return { success: true, rounds: response.data };
  } catch (error) {
    return { success: false, error: error.message };
  }
};
```

**Get Single Round with Details**:
```javascript
export const getRoundById = async (roundId) => {
  try {
    const response = await apiClient.get(`/rounds/${roundId}/`);
    // Response includes computed fields: hole_scores, counts, etc.
    return { success: true, round: response.data };
  } catch (error) {
    return { success: false, error: error.message };
  }
};
```

---

### Hole Score Management

**Save Hole Score**:
```javascript
// src/services/holeScoreService.js
export const saveHoleScore = async (scoreData) => {
  try {
    const response = await apiClient.post('/hole-scores/', {
      hole_round: scoreData.roundId,
      hole: scoreData.holeId,
      strokes: scoreData.strokes,
      swings: scoreData.swings,
      putts: scoreData.putts,
    });
    return { success: true, score: response.data };
  } catch (error) {
    return { success: false, error: error.message };
  }
};
```

**Update Hole Score**:
```javascript
export const updateHoleScore = async (scoreId, scoreData) => {
  try {
    const response = await apiClient.patch(`/hole-scores/${scoreId}/`, scoreData);
    return { success: true, score: response.data };
  } catch (error) {
    return { success: false, error: error.message };
  }
};
```

---

## State Management Integration

### Redux/Zustand Store Structure

**User Slice**:
```javascript
// src/store/userSlice.js
const userSlice = {
  state: {
    currentUser: null,
    isAuthenticated: false,
    loading: false,
  },
  actions: {
    setUser: (state, action) => {
      state.currentUser = action.payload;
      state.isAuthenticated = true;
    },
    logout: (state) => {
      state.currentUser = null;
      state.isAuthenticated = false;
    },
  },
};
```

**Round Slice**:
```javascript
// src/store/roundSlice.js
const roundSlice = {
  state: {
    activeRound: null,
    currentHole: 1,
    holeScores: [],
    rounds: [],
  },
  actions: {
    setActiveRound: (state, action) => {
      state.activeRound = action.payload;
      state.currentHole = 1;
    },
    saveHoleScore: (state, action) => {
      state.holeScores.push(action.payload);
      state.currentHole += 1;
    },
    completeRound: (state) => {
      state.activeRound = null;
      state.currentHole = 1;
      state.holeScores = [];
    },
  },
};
```

---

## Component Integration Examples

### Course Selection Component

```javascript
// src/components/CourseSelection.jsx
import React from 'react';
import { useCourses } from '../hooks/useCourses';

const CourseSelection = ({ onSelect, selectedCourse }) => {
  const { courses, loading, error } = useCourses();

  if (loading) return <div>Loading courses...</div>;
  if (error) return <div>Error: {error}</div>;

  return (
    <div className="course-selection">
      <h2>Select Course</h2>
      <div className="course-grid">
        {courses.map((course) => (
          <button
            key={course.id}
            className={`course-card ${selectedCourse === course.id ? 'selected' : ''}`}
            onClick={() => onSelect(course.id)}
          >
            <h3>{course.name}</h3>
            <p>Par {course.par}</p>
          </button>
        ))}
      </div>
    </div>
  );
};

export default CourseSelection;
```

---

### Round Play Component

```javascript
// src/components/RoundPlay.jsx
import React, { useState, useEffect } from 'react';
import { getHolesByCourse } from '../services/holeService';
import { saveHoleScore } from '../services/holeScoreService';

const RoundPlay = ({ roundId, courseId, roundLength }) => {
  const [holes, setHoles] = useState([]);
  const [currentHoleIndex, setCurrentHoleIndex] = useState(0);
  const [swings, setSwings] = useState(0);
  const [putts, setPutts] = useState(0);

  useEffect(() => {
    const fetchHoles = async () => {
      const result = await getHolesByCourse(courseId);
      if (result.success) {
        // Take only first 9 or 18 holes based on round_length
        setHoles(result.holes.slice(0, roundLength));
      }
    };
    fetchHoles();
  }, [courseId, roundLength]);

  const currentHole = holes[currentHoleIndex];
  const strokes = swings + putts;

  const handleCompleteHole = async () => {
    if (strokes === 0) return;

    const result = await saveHoleScore({
      roundId,
      holeId: currentHole.id,
      strokes,
      swings,
      putts,
    });

    if (result.success) {
      // Move to next hole
      if (currentHoleIndex < holes.length - 1) {
        setCurrentHoleIndex(currentHoleIndex + 1);
        setSwings(0);
        setPutts(0);
      } else {
        // Round complete
        alert('Round Complete!');
        window.location.href = '/round-history';
      }
    }
  };

  if (!currentHole) return <div>Loading...</div>;

  return (
    <div className="round-play">
      <div className="hole-info">
        <h2>Hole {currentHole.number}</h2>
        <p>{currentHole.distance} yards</p>
        <p>Par {currentHole.par}</p>
      </div>

      <div className="scoring">
        <div className="counter">
          <label>Swings</label>
          <button onClick={() => setSwings(Math.max(0, swings - 1))}>-</button>
          <span>{swings}</span>
          <button onClick={() => setSwings(swings + 1)}>+</button>
        </div>

        <div className="counter">
          <label>Putts</label>
          <button onClick={() => setPutts(Math.max(0, putts - 1))}>-</button>
          <span>{putts}</span>
          <button onClick={() => setPutts(putts + 1)}>+</button>
        </div>

        <div className="total">
          <strong>Total Strokes: {strokes}</strong>
        </div>
      </div>

      <button 
        onClick={handleCompleteHole}
        disabled={strokes === 0}
        className="complete-hole-btn"
      >
        Complete Hole
      </button>
    </div>
  );
};

export default RoundPlay;
```

---

### Round History Component

```javascript
// src/components/RoundHistory.jsx
import React, { useState, useEffect } from 'react';
import { getUserRounds } from '../services/roundService';

const RoundHistory = () => {
  const [rounds, setRounds] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchRounds = async () => {
      const result = await getUserRounds();
      if (result.success) {
        setRounds(result.rounds);
      }
      setLoading(false);
    };
    fetchRounds();
  }, []);

  if (loading) return <div>Loading...</div>;

  return (
    <div className="round-history">
      <h1>Round History</h1>
      {rounds.map((round) => (
        <div key={round.id} className="round-card">
          <div className="round-header">
            <h3>{round.course_name}</h3>
            <p>{round.formatted_date}</p>
          </div>
          
          <div className="round-stats">
            <div className="stat">
              <label>Score</label>
              <strong>{round.stroke_total}</strong>
            </div>
            <div className="stat">
              <label>vs Par</label>
              <strong className={round.strokes_difference.includes('+') ? 'over' : 'under'}>
                {round.strokes_difference}
              </strong>
            </div>
            <div className="stat">
              <label>Putts</label>
              <strong>{round.putt_total}</strong>
            </div>
          </div>

          <div className="score-counts">
            <span>🦅 {round.hole_scores.counts.eagles}</span>
            <span>🐦 {round.hole_scores.counts.birdies}</span>
            <span>✓ {round.hole_scores.counts.pars}</span>
            <span>+1 {round.hole_scores.counts.bogeys}</span>
            <span>+2 {round.hole_scores.counts.bogey_plus}</span>
          </div>

          {/* Expandable scorecard */}
          <div className="scorecard">
            {/* Render scorecard grid here */}
          </div>
        </div>
      ))}
    </div>
  );
};

export default RoundHistory;
```

---

## Error Handling

### Centralized Error Handler

```javascript
// src/utils/errorHandler.js
export const handleApiError = (error) => {
  if (error.response) {
    // Server responded with error status
    const status = error.response.status;
    const data = error.response.data;

    switch (status) {
      case 400:
        return {
          type: 'validation',
          message: 'Invalid input',
          fields: data,
        };
      case 401:
        return {
          type: 'auth',
          message: 'Authentication required',
        };
      case 403:
        return {
          type: 'permission',
          message: 'Permission denied',
        };
      case 404:
        return {
          type: 'notFound',
          message: 'Resource not found',
        };
      case 500:
        return {
          type: 'server',
          message: 'Server error. Please try again.',
        };
      default:
        return {
          type: 'unknown',
          message: 'An error occurred',
        };
    }
  } else if (error.request) {
    // Request made but no response
    return {
      type: 'network',
      message: 'Network error. Check your connection.',
    };
  } else {
    // Something else happened
    return {
      type: 'unknown',
      message: error.message,
    };
  }
};
```

---

## Testing Integration

### API Mock Setup

```javascript
// src/tests/mocks/handlers.js
import { rest } from 'msw';

export const handlers = [
  // Mock login
  rest.post('/api/user/login/', (req, res, ctx) => {
    return res(
      ctx.status(200),
      ctx.json({
        access: 'mock-access-token',
        refresh: 'mock-refresh-token',
      })
    );
  }),

  // Mock courses
  rest.get('/api/courses/', (req, res, ctx) => {
    return res(
      ctx.status(200),
      ctx.json([
        { id: 1, name: 'Test Course', par: 72 },
      ])
    );
  }),

  // Add more mocks...
];
```

---

## Performance Optimization

### Data Caching Strategy

```javascript
// src/utils/cache.js
const CACHE_DURATION = 5 * 60 * 1000; // 5 minutes

export class DataCache {
  constructor() {
    this.cache = new Map();
  }

  set(key, data) {
    this.cache.set(key, {
      data,
      timestamp: Date.now(),
    });
  }

  get(key) {
    const cached = this.cache.get(key);
    if (!cached) return null;

    const isExpired = Date.now() - cached.timestamp > CACHE_DURATION;
    if (isExpired) {
      this.cache.delete(key);
      return null;
    }

    return cached.data;
  }

  clear() {
    this.cache.clear();
  }
}

export const cache = new DataCache();
```

**Usage**:
```javascript
export const getCourses = async () => {
  const cached = cache.get('courses');
  if (cached) return { success: true, courses: cached };

  const result = await apiClient.get('/courses/');
  cache.set('courses', result.data);
  return { success: true, courses: result.data };
};
```

---

## Deployment Coordination

### Frontend Build Configuration

**Environment Files**:
```bash
# .env.development
VITE_API_BASE_URL=http://localhost:8000/api

# .env.production
VITE_API_BASE_URL=https://pocket-pro-api.ue.r.appspot.com/api
```

### CORS Configuration Verification

Ensure backend allows frontend origin:
```python
# Backend settings.py
CORS_ALLOWED_ORIGIN_REGEXES = [
    r"^https://.*\.web\.app$",  # Firebase
    r"^https://.*\.vercel\.app$",  # Vercel
    r"^http://localhost:.*$",  # Local dev
]
```

---

## Migration Checklist

### Pre-Integration
- [ ] Document all Clover Golf frontend features
- [ ] Map frontend components to PocketPro API endpoints
- [ ] Identify data structure differences
- [ ] Plan state management integration
- [ ] Design error handling strategy

### Integration Phase
- [ ] Set up API client with interceptors
- [ ] Implement authentication flow
- [ ] Create service layer for all endpoints
- [ ] Build reusable hooks/composables
- [ ] Integrate state management
- [ ] Add error handling
- [ ] Implement loading states

### Testing Phase
- [ ] Test authentication flow
- [ ] Test round creation and play
- [ ] Test round history retrieval
- [ ] Test error scenarios
- [ ] Perform cross-browser testing
- [ ] Test mobile responsiveness
- [ ] Load testing

### Deployment Phase
- [ ] Configure production environment variables
- [ ] Set up CI/CD pipeline
- [ ] Deploy backend to Google Cloud
- [ ] Deploy frontend to hosting platform
- [ ] Verify CORS configuration
- [ ] Test production deployment
- [ ] Set up monitoring and logging

### Post-Launch
- [ ] Monitor error rates
- [ ] Collect user feedback
- [ ] Optimize performance bottlenecks
- [ ] Plan feature enhancements
- [ ] Document lessons learned

---

## Support Resources

### Documentation References
- PocketPro API: All DOCS_*.md files
- Django REST Framework: https://www.django-rest-framework.org/
- JWT Authentication: https://django-rest-framework-simplejwt.readthedocs.io/

### Common Integration Issues
- Token expiration handling
- CORS configuration
- Database timezone handling
- File upload (if added later)
- Real-time updates (websockets if needed)

---

## Next Steps

1. **Analyze Clover Golf frontend**
   - Document existing features
   - Identify components to reuse
   - Map data flow

2. **Create unified data models**
   - Ensure frontend and backend models align
   - Define TypeScript interfaces matching Django models

3. **Implement integration layer**
   - Set up API client
   - Create service functions
   - Build custom hooks

4. **Merge and test**
   - Integrate Clover UI with PocketPro API
   - End-to-end testing
   - User acceptance testing

5. **Deploy as "Clover Golf - Production"**
   - Deploy to production environment
   - Configure custom domain
   - Launch! 🚀
