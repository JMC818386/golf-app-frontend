# PocketPro Golf App - Course & Hole Data Reference

## Overview
Complete dataset of 11 golf courses in the Lexington, Kentucky area with 199 holes including GPS coordinates.

---

## Course Listing

### 1. Tates Creek Golf Course
- **ID**: 1
- **Par**: 72
- **Holes**: 18 (IDs: 1-18)
- **Location**: Lexington, KY

**GPS Boundaries**:
- Latitude: 37.9784517 to 37.9890884
- Longitude: -84.4739092 to -84.4661497
- Altitude Range: 292.79m to 310.66m

**Hole Breakdown**:
| Hole | Par | Distance (yds) | Notes |
|------|-----|----------------|-------|
| 1 | 4 | 360 | Opening hole |
| 2 | 5 | 459 | Par 5 |
| 3 | 5 | 483 | Longest par 5 front |
| 4 | 3 | 162 | Par 3 |
| 5 | 4 | 333 | Short par 4 |
| 6 | 4 | 389 | |
| 7 | 3 | 129 | Short par 3 |
| 8 | 4 | 376 | |
| 9 | 4 | 379 | Front 9 closer |
| 10 | 4 | 378 | Back 9 start |
| 11 | 4 | 350 | |
| 12 | 4 | 367 | |
| 13 | 5 | 525 | Longest hole |
| 14 | 3 | 190 | Long par 3 |
| 15 | 4 | 382 | |
| 16 | 4 | 319 | Short par 4 |
| 17 | 3 | 160 | Par 3 |
| 18 | 5 | 524 | Closing par 5 |

**Par Distribution**: 4 par 3s, 10 par 4s, 4 par 5s

---

### 2. Lakeside Golf Course
- **ID**: 2
- **Par**: 72
- **Holes**: 18 (IDs: 19-36)
- **Location**: Lexington, KY

**GPS Boundaries**:
- Latitude: 37.9913996 to 38.0010000
- Longitude: -84.4328961 to -84.4220000
- Altitude Range: 295.17m to 311.70m

**Notable Holes**:
- Hole 2 (Par 5, 570 yds): Long par 5
- Hole 9 (Par 5, 655 yds): Longest hole in course
- Hole 6 (Par 3, 225 yds): Longest par 3

**Par Distribution**: 4 par 3s, 10 par 4s, 4 par 5s

---

### 3. Golf Club of the Bluegrass
- **ID**: 3
- **Par**: 72
- **Holes**: 18 (IDs: 37-54)
- **Location**: Lexington, KY

**GPS Boundaries**:
- Latitude: 37.9429874 to 37.9557719
- Longitude: -84.6120046 to -84.6015485
- Altitude Range: 300.22m to 313.41m

**Notable Holes**:
- Hole 10 (Par 5, 585 yds): Opening back 9
- Hole 3 (Par 5, 550 yds): Long front 9 par 5
- Hole 12 (Par 3, 215 yds): Longest par 3

**Par Distribution**: 4 par 3s, 10 par 4s, 4 par 5s

---

### 4. Gay Brewer, Jr. Course at Picadome
- **ID**: 4
- **Par**: 72
- **Holes**: 18 (IDs: 55-72)
- **Location**: Lexington, KY
- **Note**: Missing hole 11 in dataset

**GPS Boundaries**:
- Latitude: 38.0351974 to 38.0416076
- Longitude: -84.5367000 to -84.5237327
- Altitude Range: 277.88m to 290.52m

**Notable Holes**:
- Hole 3 (Par 5, 539 yds): Long early par 5
- Hole 18 (Par 5, 533 yds): Closing hole
- Hole 4 (Par 3, 129 yds): Shortest hole

**Par Distribution**: 4 par 3s, 9 par 4s, 4 par 5s (17 holes in dataset)

---

### 5. Meadowbrook Golf Course
- **ID**: 5
- **Par**: 54
- **Holes**: 18 (IDs: 73-90)
- **Type**: Par 3 Course
- **Location**: Lexington, KY

**GPS Boundaries**:
- Latitude: 37.9759461 to 37.9787454
- Longitude: -84.5165839 to -84.5123190
- Altitude Range: 282.25m to 308.29m

**Hole Range**:
- Shortest: 87 yards (Hole 11)
- Longest: 270 yards (Hole 15)
- Average: ~120 yards

**Special Features**:
- All par 3s
- Ideal for beginners and practice
- Quick rounds (under 2 hours)

---

### 6. Kearney Hills Golf Links
- **ID**: 6
- **Par**: 72
- **Holes**: 18 (IDs: 91-108)
- **Location**: Lexington, KY

**GPS Boundaries**:
- Latitude: 38.1189709 to 38.1283640
- Longitude: -84.5423109 to -84.5302735
- Altitude Range: 273.87m to 290.53m

**Notable Holes**:
- Hole 7 (Par 5, 575 yds): Longest hole
- Hole 18 (Par 5, 535 yds): Strong finish
- Hole 13 (Par 4, 465 yds): Long par 4

**Par Distribution**: 4 par 3s, 10 par 4s, 4 par 5s

---

### 7. Griffin Gate Golf Club
- **ID**: 7
- **Par**: 72
- **Holes**: 18 (IDs: 109-127)
- **Location**: Lexington, KY

**GPS Boundaries**:
- Latitude: 38.0832469 to 38.0973009
- Longitude: -84.4850248 to -84.4790620
- Altitude Range: 279.39m to 300.05m

**Notable Holes**:
- Hole 12 (Par 5, 568 yds): Back 9 long par 5
- Hole 9 (Par 5, 565 yds): Front 9 finisher
- Hole 8 (Par 3, 238 yds): Longest par 3

**Par Distribution**: 4 par 3s, 10 par 4s, 4 par 5s

---

### 8. Boone's Trace National Golf Club
- **ID**: 8
- **Par**: 72
- **Holes**: 18 (IDs: 128-145)
- **Location**: Richmond, KY

**GPS Boundaries**:
- Latitude: 37.8814233 to 37.8950157
- Longitude: -84.3792058 to -84.3615265
- Altitude Range: 231.31m to 266.81m

**Notable Holes**:
- Hole 10 (Par 5, 573 yds): Longest hole
- Hole 1 (Par 5, 537 yds): Opening hole
- Hole 6 (Par 5, 500 yds): Mid-round par 5

**Par Distribution**: 4 par 3s, 10 par 4s, 4 par 5s

---

### 9. University Club Big Blue
- **ID**: 9
- **Par**: 72
- **Holes**: 18 (IDs: 146-163)
- **Location**: Lexington, KY

**GPS Boundaries**:
- Latitude: 38.1097000 to 38.1230250
- Longitude: -84.6154312 to -84.6039882
- Altitude Range: 249.55m to 276.45m

**Notable Holes**:
- Hole 13 (Par 5, 548 yds): Long back 9 par 5
- Hole 16 (Par 5, 565 yds): Late-round challenge
- Hole 7 (Par 5, 524 yds): Front 9 par 5

**Par Distribution**: 4 par 3s, 10 par 4s, 4 par 5s

---

### 10. University Club Wildcat
- **ID**: 10
- **Par**: 71
- **Holes**: 18 (IDs: 164-179, plus 198-199)
- **Location**: Lexington, KY
- **Note**: Missing hole 2 in original dataset, added later

**GPS Boundaries**:
- Latitude: 38.1096755 to 38.1167127
- Longitude: -84.6155699 to -84.6020389
- Altitude Range: 249.55m to 276.45m

**Notable Holes**:
- Hole 1 (Par 5, 494 yds): Opening hole
- Hole 14 (Par 5, 549 yds): Long back 9
- Hole 18 (Par 5, 530 yds): Finishing par 5

**Par Distribution**: 4 par 3s, 10 par 4s, 4 par 5s = Par 71

---

### 11. Connemara Golf Course
- **ID**: 11
- **Par**: 71
- **Holes**: 18 (IDs: 180-197)
- **Location**: Nicholasville, KY

**GPS Boundaries**:
- Latitude: 37.9210214 to 37.9319715
- Longitude: -84.5592817 to -84.5519244
- Altitude Range: 283.71m to 310.64m

**Notable Holes**:
- Hole 12 (Par 5, 549 yds): Long mid-round hole
- Hole 4 (Par 5, 578 yds): Longest hole
- Hole 15 (Par 4, 530 yds): Very long par 4

**Par Distribution**: 4 par 3s, 11 par 4s, 3 par 5s = Par 71

---

## GPS Data Fields

All holes include three GPS coordinates:

### Latitude
- **Type**: Float
- **Format**: Decimal degrees
- **Range**: 37.88 to 38.12 (Lexington area)
- **Precision**: 7 decimal places
- **Use Cases**: Location mapping, distance calculation

### Longitude
- **Type**: Float
- **Format**: Decimal degrees
- **Range**: -84.65 to -84.36 (Lexington area)
- **Precision**: 7 decimal places
- **Use Cases**: Location mapping, course layout

### Altitude
- **Type**: Float
- **Unit**: Meters above sea level
- **Range**: 231m to 313m
- **Precision**: 7 decimal places
- **Use Cases**: Elevation change, shot adjustment, topography

---

## Data Quality Notes

### Missing Data
Some holes have null GPS values:
- Course 2, Hole 18 (ID 36): No GPS data
- Course 4, Hole 7 (ID 61): No GPS data
- Course 10, Hole 2 (ID 198): Added later

### Data Anomalies
- Course 3, Hole 5 (ID 41): Altitude value appears in longitude field
- Course 4, Hole 18 (ID 71): Latitude duplicated in longitude field
- Course 5, Hole 18 (ID 90): Latitude duplicated in longitude field
- Course 8, Hole 1 (ID 128): Longitude duplicated in altitude field

### Recommendations
- Validate GPS coordinates before mapping features
- Implement fallback for null values
- Consider re-surveying anomalous data points

---

## Statistical Summary

### Overall Dataset
- **Total Courses**: 11
- **Total Holes**: 199
- **Par Range**: 54 to 72
- **Distance Range**: 87 to 655 yards

### Par Distribution Across All Courses
- **Par 3s**: 40 holes (20%)
- **Par 4s**: 119 holes (60%)
- **Par 5s**: 40 holes (20%)

### Average Distances by Par
- **Par 3**: ~150-225 yards
- **Par 4**: ~300-480 yards
- **Par 5**: ~470-655 yards

### Geographic Coverage
- **Primary Area**: Lexington, KY
- **Outliers**: Richmond (Boone's Trace), Nicholasville (Connemara)
- **Elevation Range**: ~80 meters (262 feet) variation

---

## Usage in Application

### Course Selection
Fixtures loaded via:
```bash
python manage.py loaddata scoretracker/fixtures/course.json
python manage.py loaddata scoretracker/fixtures/holes.json
```

### API Access
- **All Courses**: `GET /api/courses/`
- **Course Holes**: `GET /api/holes/?selected_course={id}`
- **Single Hole**: `GET /api/holes/{id}/`

### Frontend Display
- Sort courses alphabetically
- Show par and hole count
- Display distance from user (if GPS enabled)
- Cache course data locally

### Mapping Features
- Plot courses on map using lat/long
- Calculate distances between holes
- Show elevation profiles
- Display course layout

---

## Expansion Opportunities

### Additional Data Fields
- Handicap rating
- Slope rating
- Green speed
- Fairway width
- Hazards (bunkers, water)
- Green size
- Designer/architect
- Year opened
- Course record

### New Courses
Template for adding courses:
```json
{
    "model": "scoretracker.course",
    "pk": 12,
    "fields": {
        "name": "New Golf Course",
        "par": 72
    }
}
```

Template for adding holes:
```json
{
    "model": "scoretracker.hole",
    "pk": 200,
    "fields": {
        "course": 12,
        "number": 1,
        "par": 4,
        "distance": 400,
        "latitude": 38.0000000,
        "longitude": -84.5000000,
        "altitude": 300.0000000
    }
}
```

---

## Data Validation Rules

### Course Validation
- Name: Max 50 characters
- Par: Typically 54, 70, 71, or 72
- Must have 9 or 18 holes

### Hole Validation
- Number: 1-18 for standard courses
- Par: 3, 4, or 5 (occasionally 6)
- Distance: 50-700 yards typical range
- Latitude: Valid coordinate (-90 to 90)
- Longitude: Valid coordinate (-180 to 180)
- Altitude: Reasonable for location

### Referential Integrity
- Each hole must belong to a valid course
- Hole numbers should not duplicate within a course
- GPS coordinates should be geographically consistent
