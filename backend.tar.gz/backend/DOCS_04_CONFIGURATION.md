# PocketPro Golf App - Configuration & Settings

## Django Settings Configuration

### Settings File Location
`api/settings.py`

---

## Environment Configuration

### Environment Variables Management
Uses `django-environ` for environment variable management with Google Cloud Secret Manager integration.

```python
import environ
from google.cloud import secretmanager

env = environ.Env()
env_file = os.path.join(BASE_DIR, ".env")

# Priority Order:
# 1. Local .env file (development)
# 2. Google Cloud Secret Manager (production)
# 3. Raises exception if neither found
```

### Required Environment Variables

| Variable | Type | Purpose | Example |
|----------|------|---------|---------|
| `SECRET_KEY` | String | Django secret key | Random 50-char string |
| `DATABASE_URL` | Connection String | PostgreSQL connection | `postgresql://user:pass@host:port/db` |
| `APPENGINE_URL` | URL (Optional) | Production URL | `pocket-pro-api.ue.r.appspot.com` |
| `GOOGLE_CLOUD_PROJECT` | String (Production) | GCP Project ID | `your-project-id` |
| `SETTINGS_NAME` | String (Optional) | Secret Manager name | Default: `django_settings` |
| `USE_CLOUD_SQL_AUTH_PROXY` | Boolean (Optional) | Enable Cloud SQL Proxy | `True` or `False` |

### Local .env File Example
```env
SECRET_KEY=django-insecure-your-secret-key-here
DATABASE_URL=postgresql://postgres:postgres@localhost:5432/golf_db
DEBUG=True
```

### Production Secret Manager
Secrets stored in Google Cloud Secret Manager:
- Project: Configured via `GOOGLE_CLOUD_PROJECT` env var
- Secret Name: `django_settings` (configurable)
- Version: `latest`
- Format: Multi-line key=value pairs

---

## Security Settings

### Secret Key
```python
SECRET_KEY = env('SECRET_KEY')
```
**Important**: Never commit secret key to version control

### Debug Mode
```python
DEBUG = True
```
**Warning**: Should be `False` in production

### Allowed Hosts
```python
ALLOWED_HOSTS = ['*']
```
**Warning**: Should be restricted in production to specific domains

---

## CORS Configuration

### CORS Headers Package
```python
INSTALLED_APPS = [
    ...
    'corsheaders',
    ...
]

MIDDLEWARE = [
    'corsheaders.middleware.CorsMiddleware',  # Must be before CommonMiddleware
    'django.middleware.security.SecurityMiddleware',
    ...
]
```

### CORS Settings

#### Development (No App Engine URL)
```python
if APPENGINE_URL:
    # Production settings
else:
    CSRF_TRUSTED_ORIGINS = ['http://localhost', 'https://*.gitpod.io']
    CORS_ALLOW_ALL_ORIGINS = True
```

#### Production (With App Engine URL)
```python
if APPENGINE_URL:
    # Add scheme if not present
    if not urlparse(APPENGINE_URL).scheme:
        APPENGINE_URL = f"https://{APPENGINE_URL}"
    
    CSRF_TRUSTED_ORIGINS = [APPENGINE_URL]
    CORS_ALLOWED_ORIGIN_REGEXES = [
        r"^https://.*\.gitpod\.io$",
    ]
    SECURE_SSL_REDIRECT = True
```

### Allowed Origin Patterns
```python
CORS_ALLOWED_ORIGIN_REGEXES = [
    r"^https://.*\.gitpod\.io$",      # Gitpod development
    r"^https://.*\.web\.app$",         # Firebase hosting
]
```

---

## Database Configuration

### Database Settings
```python
DATABASES = {"default": env.db()}
```

### Cloud SQL Auth Proxy Support
```python
if os.getenv("USE_CLOUD_SQL_AUTH_PROXY", None):
    DATABASES["default"]["HOST"] = "127.0.0.1"
    DATABASES["default"]["PORT"] = 5432
```

### Local Development Database
From `docker-compose.yml`:
```yaml
services:
  postgres:
    image: postgres:15.0
    ports:
      - 5432:5432
    environment:
      - "POSTGRES_PASSWORD=postgres"
```

**Connection String**:
```
postgresql://postgres:postgres@localhost:5432/golf_db
```

### Database Engine
- **Engine**: PostgreSQL
- **Driver**: `psycopg2-binary`
- **Version**: PostgreSQL 15.0

---

## Application Configuration

### Installed Apps
```python
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'rest_framework',
    'rest_framework.authtoken',
    'corsheaders',
    'scoretracker',
]
```

### Custom User Model
```python
AUTH_USER_MODEL = "scoretracker.CustomUser"
```

---

## Middleware Configuration

```python
MIDDLEWARE = [
    'corsheaders.middleware.CorsMiddleware',
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]
```

**Important Order**: CORS middleware must come before CommonMiddleware

---

## Security Headers

### X-Frame-Options
```python
X_FRAME_OPTIONS = "SAMEORIGIN"
SILENCED_SYSTEM_CHECKS = ["security.W019"]
```

---

## URL Configuration

### Root URL Config
`api/urls.py`:
```python
from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/', include('scoretracker.urls')),
]
```

### App URL Config
`scoretracker/urls.py`:
```python
from django.urls import path, include
from rest_framework import routers

router = routers.DefaultRouter()
router.register(r'courses', CourseViewSet)
router.register(r'holes', HoleViewSet)
router.register(r'rounds', RoundViewSet)
router.register(r'hole-scores', HoleScoreViewSet)

urlpatterns = [
    path('', include(router.urls)),
    path('user/signup/', UserCreate.as_view(), name="create_user"),
    path('users/<int:pk>/', UserDetail.as_view(), name="get_user_details"),
    path('user/login/', jwt_views.TokenObtainPairView.as_view(), name='token_create'),
    path('token/refresh/', jwt_views.TokenRefreshView.as_view(), name='token_refresh'),
]
```

---

## REST Framework Settings

```python
REST_FRAMEWORK = {
    'DEFAULT_PERMISSION_CLASSES': (
        'rest_framework.permissions.AllowAny',
    ),
    'DEFAULT_AUTHENTICATION_CLASSES': (
        'rest_framework_simplejwt.authentication.JWTAuthentication',
    ), 
}
```

### JWT Configuration
```python
from datetime import timedelta

SIMPLE_JWT = {
    'ACCESS_TOKEN_LIFETIME': timedelta(days=7),
    'REFRESH_TOKEN_LIFETIME': timedelta(days=14),
    'ROTATE_REFRESH_TOKENS': True,
    'BLACKLIST_AFTER_ROTATION': False,
    'ALGORITHM': 'HS256',
    'SIGNING_KEY': SECRET_KEY,
    'VERIFYING_KEY': None,
    'USER_ID_FIELD': 'id',
    'USER_ID_CLAIM': 'user_id',
    'AUTH_TOKEN_CLASSES': ('rest_framework_simplejwt.tokens.AccessToken',),
    'TOKEN_TYPE_CLAIM': 'token_type',
}
```

**Key Features**:
- Access tokens valid for 7 days
- Refresh tokens valid for 14 days
- Token rotation enabled for security
- HMAC SHA-256 algorithm

---

## Password Validation

```python
AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    },
]
```

**Validation Rules**:
- Not similar to user attributes
- Minimum 8 characters (custom in serializer)
- Not a commonly used password
- Not entirely numeric

---

## Internationalization

```python
LANGUAGE_CODE = 'en-us'
TIME_ZONE = 'UTC'
USE_I18N = True
USE_TZ = True
```

**Note**: Timezone-aware datetime handling enabled

---

## Static Files

```python
STATIC_ROOT = "static"
STATIC_URL = "/static/"
STATICFILES_DIRS = []
```

### App Engine Static File Handling
From `app.yaml`:
```yaml
handlers:
- url: /static
  static_dir: static/

- url: /.*
  script: auto
```

---

## Template Configuration

```python
TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]
```

---

## WSGI/ASGI Configuration

### WSGI Application
```python
WSGI_APPLICATION = 'api.wsgi.application'
```

File: `api/wsgi.py`
```python
import os
from django.core.wsgi import get_wsgi_application

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'api.settings')
application = get_wsgi_application()
```

### ASGI Application
File: `api/asgi.py`
```python
import os
from django.core.asgi import get_asgi_application

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'api.settings')
application = get_asgi_application()
```

---

## Default Primary Key Field

```python
DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'
```

Uses 64-bit integers for auto-incrementing primary keys.

---

## Production Deployment Checklist

### Security
- [ ] Set `DEBUG = False`
- [ ] Configure specific `ALLOWED_HOSTS`
- [ ] Use strong `SECRET_KEY` from Secret Manager
- [ ] Enable `SECURE_SSL_REDIRECT`
- [ ] Restrict CORS origins

### Database
- [ ] Configure Cloud SQL connection
- [ ] Set up database backups
- [ ] Configure connection pooling
- [ ] Enable Cloud SQL Auth Proxy if needed

### Environment
- [ ] Set all required environment variables
- [ ] Configure Google Cloud Secret Manager
- [ ] Set `GOOGLE_CLOUD_PROJECT`
- [ ] Verify `APPENGINE_URL`

### Static Files
- [ ] Run `python manage.py collectstatic`
- [ ] Verify static file serving in App Engine

### Monitoring
- [ ] Set up error logging
- [ ] Configure Cloud Monitoring
- [ ] Enable request logging

---

## Development Setup Commands

### Initial Setup
```bash
# Create virtual environment
python -m venv venv
source venv/bin/activate  # or venv\Scripts\activate on Windows

# Install dependencies
pip install -r requirements.txt

# Start PostgreSQL (Docker)
docker-compose up -d

# Run migrations
python manage.py migrate

# Load fixture data
python manage.py loaddata scoretracker/fixtures/course.json
python manage.py loaddata scoretracker/fixtures/holes.json

# Create superuser
python manage.py createsuperuser

# Run development server
python manage.py runserver
```

### Database Commands
```bash
# Make migrations
python manage.py makemigrations

# Apply migrations
python manage.py migrate

# Create database backup
python manage.py dumpdata > backup.json

# Reset database
python manage.py flush
```
