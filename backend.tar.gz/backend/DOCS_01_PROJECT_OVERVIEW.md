# PocketPro Golf App - Project Overview

## Application Name
**PocketPro**

## Description
A full-stack web application for tracking, storing, and reviewing golf scores and round data. Built as a Django REST API backend designed for integration with frontend applications.

## Project Type
- **Backend**: Django REST Framework API
- **Database**: PostgreSQL
- **Deployment**: Google Cloud Platform (App Engine)
- **Development Environment**: Docker-compose for local PostgreSQL

## Tech Stack

### Backend Framework
- **Django 4.2**
- **Django REST Framework 3.14.0**
- **Python 3.10**

### Key Dependencies
```
Django==4.2
djangorestframework==3.14.0
djangorestframework-simplejwt==5.2.2
django-cors-headers==3.14.0
django-environ==0.10.0
psycopg2-binary==2.9.6
```

### Google Cloud Services
- Google Cloud Secret Manager (2.16.1)
- Google Auth (2.17.3)
- Google API Core (2.11.0)

### Authentication
- JWT (JSON Web Tokens) using `djangorestframework-simplejwt`
- Custom User model extending Django's AbstractUser

### CORS Configuration
- Enabled for Gitpod development environments
- Configured for Firebase hosting (*.web.app domains)
- Production-ready CORS settings

## Deployment Configuration

### Google App Engine (app.yaml)
```yaml
runtime: python310
env_variables:
  APPENGINE_URL: pocket-pro-api.ue.r.appspot.com
```

### Static Files
- Static root: `static/`
- Served via App Engine static file handler

### Local Development
- Docker Compose PostgreSQL container
- Port: 5432
- Default password: postgres

## Project Structure
```
golf-app/
├── api/                    # Django project settings
│   ├── settings.py         # Main configuration
│   ├── urls.py            # Root URL routing
│   ├── wsgi.py            # WSGI application
│   └── asgi.py            # ASGI application
├── scoretracker/          # Main application
│   ├── models.py          # Database models
│   ├── serializers.py     # API serializers
│   ├── views.py           # API views
│   ├── urls.py            # App URL patterns
│   ├── admin.py           # Django admin config
│   └── fixtures/          # Test data
│       ├── course.json    # 11 golf courses
│       └── holes.json     # 199 holes with GPS data
├── manage.py              # Django management
├── requirements.txt       # Python dependencies
├── docker-compose.yml     # Local PostgreSQL setup
└── app.yaml              # GCP deployment config
```

## Core Features

### User Management
- Custom user authentication
- JWT-based token authentication
- User registration and login
- Password validation

### Course Management
- Multiple golf course support
- 11 pre-loaded courses (Lexington, KY area)
- Hole-by-hole data with GPS coordinates

### Round Tracking
- Create and track golf rounds
- 9 or 18 hole round support
- Real-time score tracking
- Swing and putt counting
- Historical round data

### Scoring System
- Hole-by-hole scoring
- Stroke, swing, and putt tracking
- Score classification (eagle, birdie, par, bogey, bogey+)
- Score differential calculations
- Complete scorecard generation

## Security Features
- Secret management via Google Cloud Secret Manager
- Environment-based configuration
- CSRF protection
- SSL/HTTPS enforcement in production
- Secure password hashing

## API Authentication
- JWT Access Tokens (7-day lifetime)
- JWT Refresh Tokens (14-day lifetime)
- Token rotation enabled
- Per-user authentication required for rounds

## Database Features
- PostgreSQL database
- Cloud SQL support with proxy
- Custom user model
- Foreign key relationships
- Timezone-aware datetime fields
- GPS coordinate storage (latitude, longitude, altitude)

## MVP Features Implemented
✅ Backend database in Django REST Framework
✅ User authentication (create account, sign in, sign out)
✅ Course and hole data management
✅ Round creation (9 or 18 holes)
✅ Real-time scoring during rounds
✅ Stroke, swing, and putt tracking
✅ Historical round viewing with statistics
✅ Score classification and analytics

## Target Integration
This backend is designed to be combined with the **Clover Golf App** frontend to create a complete full-stack production application called **"Clover Golf - Production"**.

## Environment Variables Required
- `SECRET_KEY`: Django secret key
- `DATABASE_URL`: PostgreSQL connection string
- `APPENGINE_URL`: Production deployment URL (optional)
- `GOOGLE_CLOUD_PROJECT`: GCP project ID (for production)
- `SETTINGS_NAME`: Secret Manager secret name (default: django_settings)
- `USE_CLOUD_SQL_AUTH_PROXY`: Enable Cloud SQL proxy (optional)

## Testing
- Test fixtures available for courses and holes
- ThunderClient for API testing
- Django admin interface for data management

## Future Enhancement Opportunities
- Real-time weather data integration
- Social features and round sharing
- Advanced statistics and analytics
- Course recommendations
- Handicap calculations
- Tournament management
