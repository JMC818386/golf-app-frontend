# PocketPro Golf App - API Endpoints & Serializers

## API Base URL
- **Development**: `http://localhost:8000/api/`
- **Production**: `https://pocket-pro-api.ue.r.appspot.com/api/`

## API Architecture
- RESTful API design
- JSON request/response format
- JWT token-based authentication
- ViewSets for CRUD operations
- Custom serializers with computed fields

---

## Authentication Endpoints

### 1. User Registration
**Endpoint**: `POST /api/user/signup/`

**Permission**: AllowAny (public)

**Request Body**:
```json
{
    "email": "user@example.com",
    "username": "johndoe",
    "password": "securepass123",
    "first_name": "John",
    "last_name": "Doe"
}
```

**Response** (201 Created):
```json
{
    "email": "user@example.com",
    "username": "johndoe",
    "first_name": "John",
    "last_name": "Doe"
}
```

**Validation**:
- Email: Required, valid email format
- Username: Required, unique
- Password: Minimum 8 characters, write-only
- Password is hashed before storage

**Implementation**:
```python
class UserCreate(APIView):
    permission_classes = (permissions.AllowAny,)
    authentication_classes = ()

    def post(self, request, format='json'):
        serializer = CustomUserSerializer(data=request.data)
        if serializer.is_valid():
            user = serializer.save()
            if user:
                json = serializer.data
                return Response(json, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
```

---

### 2. User Login (JWT Token)
**Endpoint**: `POST /api/user/login/`

**Permission**: AllowAny (public)

**Request Body**:
```json
{
    "username": "johndoe",
    "password": "securepass123"
}
```

**Response** (200 OK):
```json
{
    "access": "eyJ0eXAiOiJKV1QiLCJhbGc...",
    "refresh": "eyJ0eXAiOiJKV1QiLCJhbGc..."
}
```

**Token Lifetimes**:
- Access Token: 7 days
- Refresh Token: 14 days

**Usage**:
Include access token in subsequent requests:
```
Authorization: Bearer eyJ0eXAiOiJKV1QiLCJhbGc...
```

---

### 3. Token Refresh
**Endpoint**: `POST /api/token/refresh/`

**Request Body**:
```json
{
    "refresh": "eyJ0eXAiOiJKV1QiLCJhbGc..."
}
```

**Response** (200 OK):
```json
{
    "access": "eyJ0eXAiOiJKV1QiLCJhbGc...",
    "refresh": "eyJ0eXAiOiJKV1QiLCJhbGc..."
}
```

**Note**: Token rotation enabled - new refresh token returned

---

### 4. Get User Details
**Endpoint**: `GET /api/users/<id>/`

**Permission**: IsAuthenticatedOrReadOnly

**Response** (200 OK):
```json
{
    "email": "user@example.com",
    "username": "johndoe",
    "first_name": "John",
    "last_name": "Doe"
}
```

---

## Course Endpoints (ViewSet)

**Base URL**: `/api/courses/`

**Supported Methods**: GET, POST, PUT, PATCH, DELETE

### List All Courses
**Endpoint**: `GET /api/courses/`

**Response** (200 OK):
```json
[
    {
        "id": 1,
        "name": "Tates Creek Golf Course",
        "par": 72
    },
    {
        "id": 2,
        "name": "Lakeside Golf Course",
        "par": 72
    }
]
```

### Get Single Course
**Endpoint**: `GET /api/courses/<id>/`

**Response** (200 OK):
```json
{
    "id": 1,
    "name": "Tates Creek Golf Course",
    "par": 72
}
```

### Create Course
**Endpoint**: `POST /api/courses/`

**Request Body**:
```json
{
    "name": "New Golf Course",
    "par": 72
}
```

### Update Course
**Endpoint**: `PUT /api/courses/<id>/` or `PATCH /api/courses/<id>/`

### Delete Course
**Endpoint**: `DELETE /api/courses/<id>/`

---

## Hole Endpoints (ViewSet)

**Base URL**: `/api/holes/`

**Supported Methods**: GET, POST, PUT, PATCH, DELETE

### List All Holes (with Filtering)
**Endpoint**: `GET /api/holes/`

**Query Parameters**:
- `selected_course`: Filter holes by course ID

**Example**: `GET /api/holes/?selected_course=1`

**Response** (200 OK):
```json
[
    {
        "id": 1,
        "course": 1,
        "course_name": "Tates Creek Golf Course",
        "number": 1,
        "par": 4,
        "distance": 360,
        "latitude": 37.9890884,
        "longitude": -84.4722753,
        "altitude": 292.7861485
    }
]
```

**Ordering**: Results ordered by ID

**View Implementation**:
```python
def get_queryset(self):
    queryset = Hole.objects.all().order_by('id')
    course = self.request.query_params.get('selected_course')
    if course is not None:
        queryset = queryset.filter(course_id=course)
    return queryset
```

### Get Single Hole
**Endpoint**: `GET /api/holes/<id>/`

### Create Hole
**Endpoint**: `POST /api/holes/`

**Request Body**:
```json
{
    "course": 1,
    "number": 1,
    "par": 4,
    "distance": 360,
    "latitude": 37.9890884,
    "longitude": -84.4722753,
    "altitude": 292.7861485
}
```

---

## Round Endpoints (ViewSet)

**Base URL**: `/api/rounds/`

**Supported Methods**: GET, POST, PUT, PATCH, DELETE

**Authentication**: Required for all operations

### List User's Rounds
**Endpoint**: `GET /api/rounds/`

**Authentication**: Required (JWT)

**Filtering**: Automatically filtered to current user's rounds

**Response** (200 OK):
```json
[
    {
        "id": 1,
        "user": 1,
        "course": 1,
        "course_name": "Tates Creek Golf Course",
        "date": "2024-03-15T14:30:00Z",
        "round_length": 18,
        "stroke_total": 92,
        "strokes_difference": "+20",
        "putt_total": 34,
        "formatted_date": "03-15-2024",
        "hole_scores": {
            "scores": [
                {
                    "hole_number": 1,
                    "strokes": 5,
                    "par": 4,
                    "difference": 1,
                    "classification": "bogey"
                }
            ],
            "counts": {
                "eagles": 0,
                "birdies": 2,
                "pars": 8,
                "bogeys": 6,
                "bogey_plus": 2
            }
        }
    }
]
```

### Serializer Features

**Computed Fields**:
- `course_name`: Nested course name from relationship
- `formatted_date`: Date in MM-DD-YYYY format
- `stroke_total`: Sum of all hole strokes in round
- `putt_total`: Sum of all putts in round
- `strokes_difference`: Score relative to par (+/-)
- `hole_scores`: Detailed hole-by-hole breakdown with classifications

**Implementation**:
```python
class RoundSerializer(serializers.ModelSerializer):
    course_name = serializers.CharField(source='course.name', required=False)
    formatted_date = serializers.SerializerMethodField()
    stroke_total = serializers.SerializerMethodField()
    putt_total = serializers.SerializerMethodField()
    hole_scores = serializers.SerializerMethodField()
    strokes_difference = serializers.SerializerMethodField()
```

**Score Calculation Methods**:
```python
def get_stroke_total(self, obj):
    scores = HoleScore.objects.filter(hole_round_id=obj.id)
    stroke_total = 0
    for score in scores:
        stroke_total += score.strokes
    return stroke_total

def get_putt_total(self, obj):
    scores = HoleScore.objects.filter(hole_round_id=obj.id)
    putt_total = 0
    for score in scores:
        putt_total += score.putts
    return putt_total

def get_strokes_difference(self, obj):
    scores = HoleScore.objects.filter(hole_round_id=obj.id)
    total_score = 0
    par = 0
    
    for score in scores:
        hole = score.hole
        if hole is not None:
            total_score += score.strokes
            par += hole.par
    
    difference = total_score - par
    return difference if difference < 0 else f'+{difference}'
```

**Hole Scores with Classification**:
```python
def get_hole_scores(self, obj):
    hole_scores = []
    scores = HoleScore.objects.filter(hole_round_id=obj.id).order_by('hole__number')
    holes = Hole.objects.filter(course=obj.course).order_by('number')

    for score, hole in zip(scores, holes):
        par = hole.par
        strokes = score.strokes
        difference = strokes - par
        classification = None

        if difference == -2:
            classification = 'eagle'
        elif difference == -1:
            classification = 'birdie'
        elif difference == 0:
            classification = 'par'
        elif difference == 1:
            classification = 'bogey'
        else:
            classification = 'bogey_plus'

        hole_score_data = {
            'hole_number': hole.number,
            'strokes': strokes,
            'par': par,
            'difference': difference,
            'classification': classification
        }
        hole_scores.append(hole_score_data)

    # Calculate totals
    eagle_count = sum(score['classification'] == 'eagle' for score in hole_scores)
    birdie_count = sum(score['classification'] == 'birdie' for score in hole_scores)
    par_count = sum(score['classification'] == 'par' for score in hole_scores)
    bogey_count = sum(score['classification'] == 'bogey' for score in hole_scores)
    bogeyplus_count = sum(score['classification'] == 'bogey_plus' for score in hole_scores)

    counts = {
        'eagles': eagle_count,
        'birdies': birdie_count,
        'pars': par_count,
        'bogeys': bogey_count,
        'bogey_plus': bogeyplus_count
    }

    return {'scores': hole_scores, 'counts': counts}
```

### Create Round
**Endpoint**: `POST /api/rounds/`

**Request Body**:
```json
{
    "course": 1,
    "round_length": 18,
    "total_score": 92
}
```

**Note**: User automatically set from JWT token

**Implementation**:
```python
def perform_create(self, serializer):
    serializer.save(user=self.request.user)
```

### Get Single Round
**Endpoint**: `GET /api/rounds/<id>/`

### Update Round
**Endpoint**: `PUT /api/rounds/<id>/` or `PATCH /api/rounds/<id>/`

---

## Hole Score Endpoints (ViewSet)

**Base URL**: `/api/hole-scores/`

**Supported Methods**: GET, POST, PUT, PATCH, DELETE

### List Hole Scores
**Endpoint**: `GET /api/hole-scores/`

**Response** (200 OK):
```json
[
    {
        "user": 1,
        "hole_round": 1,
        "hole": 1,
        "strokes": 5,
        "swings": 3,
        "putts": 2
    }
]
```

### Create Hole Score
**Endpoint**: `POST /api/hole-scores/`

**Request Body**:
```json
{
    "hole_round": 1,
    "hole": 1,
    "strokes": 5,
    "swings": 3,
    "putts": 2
}
```

**Serializer**:
```python
class HoleScoreSerializer(serializers.ModelSerializer):
    user = serializers.PrimaryKeyRelatedField(queryset=CustomUser.objects.all(), required=False)
    
    class Meta:
        model = HoleScore
        fields = ['user', 'hole_round', 'hole', 'strokes', 'swings', 'putts']
```

---

## API Summary Table

| Endpoint | Method | Auth Required | Purpose |
|----------|--------|---------------|---------|
| `/api/user/signup/` | POST | No | Register new user |
| `/api/user/login/` | POST | No | Get JWT tokens |
| `/api/token/refresh/` | POST | No | Refresh access token |
| `/api/users/<id>/` | GET | Optional | Get user details |
| `/api/courses/` | GET | No | List all courses |
| `/api/courses/<id>/` | GET/PUT/PATCH/DELETE | No | Course CRUD |
| `/api/holes/` | GET | No | List holes (filterable) |
| `/api/holes/<id>/` | GET/PUT/PATCH/DELETE | No | Hole CRUD |
| `/api/rounds/` | GET/POST | Yes | User's rounds |
| `/api/rounds/<id>/` | GET/PUT/PATCH/DELETE | Yes | Round CRUD |
| `/api/hole-scores/` | GET/POST | No | Hole score operations |
| `/api/hole-scores/<id>/` | GET/PUT/PATCH/DELETE | No | Hole score CRUD |

---

## REST Framework Configuration

```python
REST_FRAMEWORK = {
    'DEFAULT_PERMISSION_CLASSES': (
        'rest_framework.permissions.AllowAny',
    ),
    'DEFAULT_AUTHENTICATION_CLASSES': (
        'rest_framework_simplejwt.authentication.JWTAuthentication',
    ), 
}

SIMPLE_JWT = {
    'ACCESS_TOKEN_LIFETIME': timedelta(days=7),
    'REFRESH_TOKEN_LIFETIME': timedelta(days=14),
    'ROTATE_REFRESH_TOKENS': True,
    'BLACKLIST_AFTER_ROTATION': False,
    'ALGORITHM': 'HS256',
    'SIGNING_KEY': SECRET_KEY,
    'VERIFYING_KEY': None,
    'USER_ID_FIELD': 'id',
    'USER_ID_CLAIM': 'user_id',
    'AUTH_TOKEN_CLASSES': ('rest_framework_simplejwt.tokens.AccessToken',),
    'TOKEN_TYPE_CLAIM': 'token_type',
}
```

---

## Error Responses

### 400 Bad Request
```json
{
    "field_name": ["Error message"]
}
```

### 401 Unauthorized
```json
{
    "detail": "Authentication credentials were not provided."
}
```

### 404 Not Found
```json
{
    "detail": "Not found."
}
```

---

## Testing with ThunderClient
- Import endpoints into ThunderClient
- Set base URL variable
- Include JWT token in headers for authenticated endpoints
- Test CRUD operations for all resources
