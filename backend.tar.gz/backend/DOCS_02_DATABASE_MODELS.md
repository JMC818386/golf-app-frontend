# PocketPro Golf App - Database Models & Schema

## Models Overview
The application uses 5 core models that handle user authentication, golf courses, holes, rounds, and individual hole scoring.

---

## 1. CustomUser Model

**Purpose**: Extended Django user model for authentication and user management.

### Model Definition
```python
from django.contrib.auth.models import AbstractUser

class CustomUser(AbstractUser):
    
    def __str__(self):
        return self.username
```

### Inherited Fields (from AbstractUser)
| Field | Type | Description |
|-------|------|-------------|
| id | AutoField (PK) | Unique user identifier |
| username | varchar(150) | Unique username |
| password | password | Hashed password |
| email | email | User email address |
| first_name | varchar(150) | User's first name |
| last_name | varchar(150) | User's last name |
| is_superuser | boolean | Admin status |
| is_staff | boolean | Staff status |
| is_active | boolean | Account active status |
| last_login | datetime | Last login timestamp |
| date_joined | datetime | Account creation date |

### Relationships
- **One-to-Many**: User can have multiple Rounds

### Key Features
- Password hashing built-in
- Django admin integration
- Permission system included
- Session management support

---

## 2. Course Model

**Purpose**: Represents a golf course with basic information.

### Model Definition
```python
class Course(models.Model):
    name = models.CharField(max_length=50)
    par = models.IntegerField()

    def __str__(self):
        return f'{self.name}, {self.par}'
```

### Fields
| Field | Type | Constraints | Description |
|-------|------|-------------|-------------|
| id | Integer (PK) | Auto-increment | Unique course identifier |
| name | CharField(50) | Required | Golf course name |
| par | IntegerField | Required | Total par for the course |

### Relationships
- **One-to-Many**: Course has multiple Holes
- **One-to-Many**: Course can be played in multiple Rounds

### Sample Data (11 Courses)
1. Tates Creek Golf Course (Par 72)
2. Lakeside Golf Course (Par 72)
3. Golf Club of the Bluegrass (Par 72)
4. Gay Brewer, Jr. Course at Picadome (Par 72)
5. Meadowbrook Golf Course (Par 54) *9-hole course*
6. Kearney Hills Golf Links (Par 72)
7. Griffin Gate Golf Club (Par 72)
8. Boone's Trace National Golf Club (Par 72)
9. University Club Big Blue (Par 72)
10. University Club Wildcat (Par 71)
11. Connemara Golf Course (Par 71)

---

## 3. Hole Model

**Purpose**: Represents individual holes within a golf course with GPS data.

### Model Definition
```python
class Hole(models.Model):
    course = models.ForeignKey('Course', on_delete=models.CASCADE)
    number = models.IntegerField()
    par = models.IntegerField()
    distance = models.IntegerField()
    latitude = models.FloatField(null=True)
    longitude = models.FloatField(null=True)
    altitude = models.FloatField(null=True)
   
    def __str__(self):
        return f'{self.course}, {self.par}, {self.distance}, {self.number}'
```

### Fields
| Field | Type | Constraints | Description |
|-------|------|-------------|-------------|
| id | Integer (PK) | Auto-increment | Unique hole identifier |
| course | ForeignKey | Required, CASCADE | Reference to Course |
| number | IntegerField | Required | Hole number (1-18) |
| par | IntegerField | Required | Par for this hole (3, 4, or 5) |
| distance | IntegerField | Required | Distance in yards |
| latitude | FloatField | Nullable | GPS latitude coordinate |
| longitude | FloatField | Nullable | GPS longitude coordinate |
| altitude | FloatField | Nullable | Elevation in meters |

### Relationships
- **Many-to-One**: Multiple holes belong to one Course
- **One-to-Many**: Hole can have multiple HoleScores across different rounds

### GPS Data
- 199 holes with complete GPS coordinates
- Enables mapping and distance calculation features
- Altitude data for elevation tracking

### Hole Configuration Examples
- **Par 3**: Typically 100-225 yards
- **Par 4**: Typically 300-480 yards
- **Par 5**: Typically 485-655 yards

---

## 4. Round Model

**Purpose**: Represents a complete golf round played by a user.

### Model Definition
```python
from django.utils import timezone

class Round(models.Model):
    user = models.ForeignKey('CustomUser', on_delete=models.CASCADE, null=True)
    course = models.ForeignKey('Course', on_delete=models.CASCADE, null=True)
    date = models.DateTimeField(default=timezone.now, null=True)
    round_length = models.IntegerField(null=True)
    total_score = models.IntegerField(null=True)

    def __str__(self):
        return f'{self.user}, {self.course}, {self.date}, {self.round_length}, {self.total_score}'
```

### Fields
| Field | Type | Constraints | Description |
|-------|------|-------------|-------------|
| id | Integer (PK) | Auto-increment | Unique round identifier |
| user | ForeignKey | CASCADE, Nullable | Reference to CustomUser |
| course | ForeignKey | CASCADE, Nullable | Reference to Course |
| date | DateTimeField | Default: now, Nullable | When round was played |
| round_length | IntegerField | Nullable | Number of holes (9 or 18) |
| total_score | IntegerField | Nullable | Total strokes for the round |

### Relationships
- **Many-to-One**: Multiple rounds belong to one User
- **Many-to-One**: Multiple rounds can be played on one Course
- **One-to-Many**: Round has multiple HoleScores

### Business Rules
- `round_length` should be 9 or 18
- `total_score` is sum of all hole strokes
- Date automatically set to current time on creation
- User association for round ownership and filtering

---

## 5. HoleScore Model

**Purpose**: Stores detailed scoring data for each hole in a round.

### Model Definition
```python
class HoleScore(models.Model):
    hole_round = models.ForeignKey('Round', on_delete=models.CASCADE, null=True)
    hole = models.ForeignKey('Hole', on_delete=models.CASCADE, null=True)
    strokes = models.IntegerField(null=True)
    swings = models.IntegerField(null=True)
    putts = models.IntegerField(null=True)
   
    def __str__(self):
        return f'{self.hole_round}, {self.hole}, {self.strokes}, {self.swings}, {self.putts}'
```

### Fields
| Field | Type | Constraints | Description |
|-------|------|-------------|-------------|
| id | Integer (PK) | Auto-increment | Unique hole score identifier |
| hole_round | ForeignKey | CASCADE, Nullable | Reference to Round |
| hole | ForeignKey | CASCADE, Nullable | Reference to Hole |
| strokes | IntegerField | Nullable | Total strokes taken |
| swings | IntegerField | Nullable | Number of full swings |
| putts | IntegerField | Nullable | Number of putts |

### Relationships
- **Many-to-One**: Multiple hole scores belong to one Round
- **Many-to-One**: Multiple hole scores can reference one Hole (across different rounds)

### Score Tracking Details
- **Strokes**: Total shots including swings and putts
- **Swings**: Full swings (drives, approach shots, chips)
- **Putts**: Shots taken on the green
- **Relationship**: strokes = swings + putts (typically)

### Score Classification Logic
Based on difference from par:
- **Eagle**: strokes - par = -2
- **Birdie**: strokes - par = -1
- **Par**: strokes - par = 0
- **Bogey**: strokes - par = 1
- **Bogey+**: strokes - par > 1

---

## Database Schema Relationships

```
CustomUser (1) ──────< (Many) Round
                                │
Course (1) ──────< (Many) Hole  │
                                │
Course (1) ──────< (Many) Round │
                                │
Round (1) ──────< (Many) HoleScore >────── (Many) Hole (1)
```

---

## Migrations History

### Migration Files
1. **0001_initial.py**: Initial CustomUser model
2. **0002_course_hole.py**: Added Course and Hole models
3. **0003_round.py**: Added Round model
4. **0004_alter_round_course_alter_round_date_and_more.py**: Modified Round fields
5. **0005_holescore.py**: Added HoleScore model
6. **0006_hole_altitude_hole_latitude_hole_longitude.py**: Added GPS coordinates to Hole

---

## Data Constraints & Validation

### Required Validations (Application Level)
- User must be authenticated to create rounds
- Round length must be 9 or 18
- Par values typically 3, 4, or 5
- Strokes should be positive integers
- Swings and putts should be non-negative

### Database Constraints
- CASCADE deletes: Deleting Course removes all Holes
- CASCADE deletes: Deleting Round removes all HoleScores
- CASCADE deletes: Deleting User removes all Rounds
- NULL allowed on most foreign keys for flexibility

---

## Fixtures Data

### course.json
- 11 golf courses in Lexington, KY area
- Mix of par 54, 71, and 72 courses
- Ready for immediate use in development/testing

### holes.json
- 199 complete hole records
- GPS coordinates (lat/long/altitude)
- Distances in yards
- Par ratings (3, 4, or 5)
- Mapped to specific courses

---

## Admin Configuration

All models registered in Django admin:
```python
admin.site.register(CustomUser)
admin.site.register(Course)
admin.site.register(Hole)
admin.site.register(Round)
admin.site.register(HoleScore)
```

Provides full CRUD operations via Django admin interface.
