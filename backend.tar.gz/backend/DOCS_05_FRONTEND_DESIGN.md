# PocketPro Golf App - Frontend UI/UX Design Specifications

## Design Approach
Atomic Design methodology for component organization and reusability.

---

## Page Structure & Components

### 1. Sign In Page

**Purpose**: User authentication entry point

#### Components
- **Sign In Header Text**
  - Large, prominent header
  - Application branding

- **Username Section**
  - Subheader Text: "Username"
  - Username Input Field
    - Type: text
    - Validation: Required
    - Placeholder: "Enter username"

- **Password Section**
  - Subheader Text: "Password"
  - Password Input Field
    - Type: password
    - Validation: Required, min 8 characters
    - Placeholder: "Enter password"

- **Action Buttons**
  - Login Button
    - Primary action
    - Triggers authentication
    - Shows loading state
    - Navigates to Main Menu on success
  
  - Create Account Button
    - Secondary action
    - Navigates to Create Account Page

#### API Integration
- **Endpoint**: `POST /api/user/login/`
- **Request**: `{ username, password }`
- **Response**: JWT tokens (access, refresh)
- **Storage**: Save tokens to localStorage/sessionStorage
- **Error Handling**: Display validation errors inline

---

### 2. Create Account Page

**Purpose**: New user registration

#### Components
- **New Account Header Text**
  - Clear registration title

- **First Name Section**
  - Subheader Text: "First Name"
  - First Name Input Field
    - Type: text
    - Validation: Required
    - Placeholder: "First name"

- **Last Name Section**
  - Subheader Text: "Last Name"
  - Last Name Input Field
    - Type: text
    - Validation: Required
    - Placeholder: "Last name"

- **Email Section**
  - Subheader Text: "Email"
  - Email Input Field
    - Type: email
    - Validation: Required, valid email format
    - Placeholder: "your.email@example.com"

- **Username Section**
  - Subheader Text: "Username"
  - Username Input Field
    - Type: text
    - Validation: Required, unique
    - Placeholder: "Choose a username"

- **Password Section**
  - Subheader Text: "Password"
  - Password Input Field
    - Type: password
    - Validation: Required, min 8 characters
    - Show password strength indicator
    - Placeholder: "Create password (min 8 characters)"

- **Create Account Button**
  - Primary action
  - Triggers registration
  - Shows loading state
  - Auto-login and navigate to Main Menu on success

#### API Integration
- **Endpoint**: `POST /api/user/signup/`
- **Request**: `{ email, username, password, first_name, last_name }`
- **Success**: Auto-login user, navigate to Main Menu
- **Error Handling**: Display field-specific errors

---

### 3. Main Menu Page

**Purpose**: Primary navigation hub

#### Components
- **Logo Header**
  - Prominent app logo/branding
  - Centered at top

- **Navigation Buttons** (Vertical Stack)
  - **New Round Button**
    - Primary action
    - Navigates to New Round Setup Page
    - Icon: Play/Golf Ball
  
  - **Round History Button**
    - Navigate to Round History Page
    - Icon: List/History
  
  - **Account Button**
    - Navigate to Account Settings
    - Icon: User Profile
  
  - **Sign Out Button**
    - Secondary/Danger style
    - Clears authentication tokens
    - Returns to Sign In Page
    - Icon: Logout

#### User Experience
- Authenticated users only
- Display username/greeting at top
- Quick access to all major features

---

### 4. New Round Setup Page

**Purpose**: Configure a new golf round before playing

#### Components
- **Logo Header**
  - Consistent branding

- **Course Selection Section**
  - Course Header Text: "Select Course"
  - Multiple Golf Course Buttons
    - Display: Course name and par
    - State: Selected/Unselected
    - Data from: `GET /api/courses/`
    - Example: "Tates Creek Golf Course (Par 72)"

- **Round Length Section**
  - Round Length Header Text: "Round Length"
  - Toggle Options:
    - **9 Hole Button**
      - State: Selected/Unselected
    - **18 Hole Button**
      - State: Selected/Unselected
  - Note: Mutually exclusive selection

- **Action Buttons**
  - **Begin Round Button**
    - Primary action
    - Enabled only when course AND length selected
    - Creates round in database
    - Navigates to Round Page
    - API: `POST /api/rounds/`
  
  - **Main Menu Button**
    - Secondary action
    - Return without creating round

#### Data Flow
1. Load courses from API
2. User selects course
3. Fetch holes for selected course: `GET /api/holes/?selected_course={id}`
4. User selects length (9 or 18)
5. Create round record
6. Navigate to Round Page with round ID

---

### 5. Round Page (Active Play)

**Purpose**: Real-time score tracking during play

#### Header Section

**Hole Info Box**
- **Hole Number Text**: "Hole 1" - "Hole 18"
- **Hole Distance Text**: "360 yards"
- **Hole Par Text**: "Par 4"

#### Stats Display

**Total Numbers Box** (3 columns)

1. **Distance Box**
   - Distance Header Text: "Distance"
   - Distance Number Text: Total yards for round
   - Updates as holes progress

2. **Total Strokes Box**
   - Strokes Header Text: "Strokes"
   - Current Stroke Number
   - Updates automatically from swings + putts
   - Running total for round

3. **Current Score Box**
   - Header Text: "+/-"
   - Current Score Text: "+5", "-2", "E" (even)
   - Relative to par
   - Color coding: Red (over), Green (under), Black (even)

#### Input Section

**Total Swings Box**
- Swings Header Text: "Swings"
- Decrement Button (-)
  - Decrease swing count
  - Min: 0
- Swings Number (Display)
  - Current hole swings
- Increment Button (+)
  - Increase swing count
- **Auto-update**: Increments total strokes

**Total Putts Box**
- Putts Header Text: "Putts"
- Decrement Button (-)
  - Decrease putt count
  - Min: 0
- Putts Number (Display)
  - Current hole putts
- Increment Button (+)
  - Increase putt count
- **Auto-update**: Increments total strokes

#### Scorecard Display

**Front 9 Scorecard** (Grid Layout)
- **Row 1: Hole Numbers**
  - Cells: 1, 2, 3, 4, 5, 6, 7, 8, 9, OUT, (empty)
  
- **Row 2: Pars**
  - Par value for each hole
  - OUT: Total front 9 par
  
- **Row 3: Strokes**
  - Updates with GET requests as scores POST
  - OUT: Total front 9 strokes
  - Color coding by classification

**Back 9 Scorecard** (Grid Layout)
- **Row 1: Hole Numbers**
  - Cells: 10, 11, 12, 13, 14, 15, 16, 17, 18, IN, TOTAL
  
- **Row 2: Pars**
  - Par value for each hole
  - IN: Total back 9 par
  - TOTAL: Total round par
  
- **Row 3: Strokes**
  - Updates as scores POST
  - IN: Total back 9 strokes
  - TOTAL: Total round strokes

**Cell Color Coding**:
- Eagle (-2): Gold/Yellow
- Birdie (-1): Light Green
- Par (0): White/Default
- Bogey (+1): Light Red
- Double Bogey+ (2+): Dark Red

#### Action Buttons

- **Complete Hole Button**
  - Primary action
  - Enabled when swings or putts > 0
  - Saves hole score: `POST /api/hole-scores/`
  - Request: `{ hole_round, hole, strokes, swings, putts }`
  - Advances to next hole
  - Last hole: Shows "Complete Round" button
  
- **Main Menu Button**
  - Secondary action
  - Save progress and exit
  - Confirmation dialog if mid-round

#### Real-time Updates
- Automatic scorecard refresh
- Live statistics calculation
- Smooth transitions between holes

---

### 6. Round History Page

**Purpose**: View and analyze completed rounds

#### Header
- **Logo Header**
- **Round History Header Text**

#### Round List

Each **Single Round Box** contains:

**Key Stats Box** (Top Section)
- **Course Name Text**: Full course name
- **Round Date Text**: Formatted date (MM-DD-YYYY)
- **Amount Over/Under Par Text**: "+5" or "-3"
  - Color coded (red/green)
- **Total Putts Text**: "34 Putts"
- **Total Score Text**: "92 Strokes"

**Score Type Amount Box** (Statistics)
Display counts for:
- **Eagle Amount Text**: "0 Eagles"
- **Birdie Amount Text**: "2 Birdies"
- **Par Amount Text**: "8 Pars"
- **Bogey Amount Text**: "6 Bogeys"
- **Bogey+ Amount Text**: "2 Bogey+"

**Complete Scorecard Display**

**Front 9 Scorecard**
- **Row 1: Numbers**: 1-9, OUT, (empty)
- **Row 2: Pars**: Par for each hole + front total
- **Row 3: Strokes**: Actual strokes + front total

**Back 9 Scorecard**
- **Row 1: Numbers**: 10-18, IN, TOTAL
- **Row 2: Pars**: Par for each hole + back total + overall total par
- **Row 3: Strokes**: Actual strokes + back total + overall total strokes

**Visual Enhancements**:
- Color-coded cells by classification
- Expandable/collapsible rounds
- Sort options: Date, Score, Course

#### Action Buttons
- **Main Menu Button**: Return to main menu
- **Filter/Sort Controls**: Filter by course, date range
- **Detail View Button**: Expand individual round for full stats

#### API Integration
- **Endpoint**: `GET /api/rounds/`
- **Response**: Array of rounds with computed fields
- **Features**:
  - Automatic calculation of differentials
  - Score classifications
  - Aggregate statistics
  - Formatted dates

---

## Component Hierarchy

### Atomic Design Structure

**Atoms** (Basic UI Elements)
- Text inputs
- Buttons
- Labels
- Number displays
- Icons

**Molecules** (Simple Component Groups)
- Input field with label
- Increment/Decrement controls
- Stat display box
- Score cell

**Organisms** (Complex Components)
- Scorecard grid
- Round summary card
- Course selector
- Stats dashboard

**Templates** (Page Layouts)
- Authentication layout
- Dashboard layout
- Game play layout
- History layout

**Pages** (Complete Views)
- Sign In Page
- Create Account Page
- Main Menu
- New Round Setup
- Active Round Page
- Round History Page

---

## Responsive Design Considerations

### Mobile First Approach
- Touch-friendly buttons (min 44x44px)
- Large tap targets for increment/decrement
- Scrollable scorecard on small screens
- Simplified layout for narrow viewports

### Tablet Optimization
- Side-by-side layouts where appropriate
- Enhanced scorecard visibility
- Multi-column stats display

### Desktop Experience
- Full scorecard always visible
- Dashboard-style layout
- Keyboard shortcuts
- Mouse hover states

---

## State Management Requirements

### Global State
- Current user
- Authentication tokens
- Active round (if playing)

### Page State
- Form inputs
- Selected course/length
- Current hole
- Swing/putt counters
- Scorecard data

### API State
- Loading states
- Error messages
- Success notifications
- Cache invalidation

---

## User Flow Summary

```
Sign In / Create Account
        ↓
   Main Menu
        ↓
   ┌────┴────┐
   ↓         ↓
New Round   Round History
   ↓
Setup Round
   ↓
Play Round (Holes 1-18)
   ↓
Complete Round
   ↓
View in History
```

---

## Color Scheme Suggestions

### Score Classifications
- **Eagle**: `#FFD700` (Gold)
- **Birdie**: `#90EE90` (Light Green)
- **Par**: `#FFFFFF` (White)
- **Bogey**: `#FFB6C1` (Light Red)
- **Double+**: `#FF6B6B` (Red)

### UI Elements
- **Primary Action**: Blue/Green
- **Secondary Action**: Gray
- **Danger/Warning**: Red
- **Success**: Green
- **Background**: Light gray/white
- **Text**: Dark gray/black

---

## Accessibility Features
- ARIA labels on all interactive elements
- Keyboard navigation support
- Screen reader friendly
- High contrast mode support
- Focus indicators
- Error announcements

---

## Performance Optimization
- Lazy load round history
- Debounce increment/decrement
- Optimize scorecard rendering
- Cache course/hole data
- Minimize API calls during play
